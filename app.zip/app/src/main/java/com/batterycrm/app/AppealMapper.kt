package com.batterycrm.app

import com.batterycrm.app.models.Appeal as ApiAppeal

fun ApiAppeal.toUiAppeal(): Appeal {
    return Appeal(
        id = this.id.toString(),
        clientName = this.client?.name ?: "Unknown",
        lastMessage = this.last_message ?: "No messages",
        timestamp = formatTimestamp(this.updated_at),
        isUnread = this.status == "new",
        appealType = this.appeal_type,
        repairType = this.repair_type,
        deviceModel = "${this.device?.brand ?: ""} ${this.device?.model ?: ""}".trim()
    )
}

private fun formatTimestamp(timestamp: String): String {
    // Простое форматирование, можно улучшить
    return try {
        timestamp.substring(0, 16).replace("T", " ")
    } catch (e: Exception) {
        timestamp
    }
}
