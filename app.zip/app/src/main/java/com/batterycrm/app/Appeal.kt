package com.batterycrm.app

data class Appeal(
    val id: String,
    val clientName: String,
    val lastMessage: String,
    val timestamp: String,
    val isUnread: Boolean,
    val appealType: String?,
    val repairType: String?,
    val deviceModel: String?
)
