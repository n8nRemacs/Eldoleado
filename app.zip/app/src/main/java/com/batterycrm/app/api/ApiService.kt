package com.batterycrm.app.api

import com.batterycrm.app.models.Appeal
import com.batterycrm.app.models.Message
import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    
    @GET("android/appeals/list")
    fun getAppealsList(
        @Query("operator_id") operatorId: Int,
        @Query("status") status: String? = null,
        @Query("limit") limit: Int = 20
    ): Call<AppealsListResponse>
    
    @GET("android-appeal-detail/android/appeals/{id}")
    fun getAppealDetail(
        @Path("id") appealId: Int,
        @Query("limit") limit: Int = 50
    ): Call<AppealDetailResponse>
    
    @POST("android-send-response/android/appeals/{id}/send")
    fun sendResponse(
        @Path("id") appealId: Int,
        @Body request: SendMessageRequest
    ): Call<ApiResponse>
    
    @POST("android-normalize/android/appeals/{id}/normalize")
    fun normalizeText(
        @Path("id") appealId: Int,
        @Body request: NormalizeRequest
    ): Call<NormalizeResponse>
    
    @POST("android-reject/android/appeals/{id}/reject")
    fun rejectAiResponse(
        @Path("id") appealId: Int,
        @Body request: RejectRequest
    ): Call<ApiResponse>
    
    @POST("android-send-promo/android/appeals/{id}/promo")
    fun sendPromo(
        @Path("id") appealId: Int,
        @Body request: PromoRequest
    ): Call<ApiResponse>
    
    @POST("android-take-appeal/android/appeals/{id}/take")
    fun takeAppeal(
        @Path("id") appealId: Int,
        @Body request: TakeAppealRequest
    ): Call<ApiResponse>
}

data class AppealsListResponse(
    val success: Boolean,
    val appeals: List<Appeal>,
    val count: Int
)

data class AppealDetailResponse(
    val success: Boolean,
    val appeal: Appeal,
    val messages: List<Message>,
    val ai_response: AiResponse?
)

data class AiResponse(
    val id: Int,
    val response_text: String,
    val status: String,
    val created_at: String
)

data class ApiResponse(
    val success: Boolean,
    val appeal_id: Int? = null,
    val error: String? = null
)

data class NormalizeRequest(
    val operator_id: Int,
    val response_text: String
)

data class NormalizeResponse(
    val success: Boolean,
    val normalized_text: String
)

data class RejectRequest(
    val operator_id: Int,
    val reject_reason: String? = null
)

data class PromoRequest(
    val operator_id: Int
)

data class TakeAppealRequest(
    val operator_id: Int
)