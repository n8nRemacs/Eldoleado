package com.batterycrm.app.api

data class SendMessageRequest(
    val operator_id: Int,
    val response_text: String?,
    val media_type: String?,
    val media_data: String?
)
