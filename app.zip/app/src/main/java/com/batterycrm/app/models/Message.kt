package com.batterycrm.app.models

data class Message(
    val id: Int,
    val text: String?,
    val media_type: String?,
    val media_url: String?,
    val sender_type: String,
    val created_at: String
)
