package com.batterycrm.app

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.batterycrm.app.adapters.MessagesAdapter
import com.batterycrm.app.api.AppealDetailResponse
import com.batterycrm.app.api.ApiResponse
import com.batterycrm.app.api.RetrofitClient
import com.batterycrm.app.api.SendMessageRequest
import com.batterycrm.app.models.Message
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AppealDetailActivity : AppCompatActivity() {
    
    private lateinit var messagesRecyclerView: RecyclerView
    private lateinit var messageInput: EditText
    private lateinit var sendButton: Button
    private lateinit var messagesAdapter: MessagesAdapter
    private val messages = mutableListOf<Message>()
    private var appealId: Int = 0
    private var operatorId: Int = 1
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_appeal_detail)
        
        appealId = intent.getIntExtra("appeal_id", 0)
        
        messagesRecyclerView = findViewById(R.id.messagesRecyclerView)
        messageInput = findViewById(R.id.messageInput)
        sendButton = findViewById(R.id.sendButton)
        
        messagesAdapter = MessagesAdapter(messages)
        messagesRecyclerView.layoutManager = LinearLayoutManager(this)
        messagesRecyclerView.adapter = messagesAdapter
        
        sendButton.setOnClickListener {
            sendMessage()
        }
        
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        loadAppealDetails()
    }
    
    private fun loadAppealDetails() {
        RetrofitClient.apiService.getAppealDetail(appealId).enqueue(object : Callback<AppealDetailResponse> {
            override fun onResponse(
                call: Call<AppealDetailResponse>,
                response: Response<AppealDetailResponse>
            ) {
                if (response.isSuccessful) {
                    response.body()?.let { detailResponse ->
                        supportActionBar?.title = detailResponse.appeal.number
                        supportActionBar?.subtitle = "${detailResponse.appeal.client?.name ?: "Unknown"} - ${detailResponse.appeal.device?.brand ?: ""} ${detailResponse.appeal.device?.model ?: ""}"
                        
                        messages.clear()
                        messages.addAll(detailResponse.messages)
                        messagesAdapter.notifyDataSetChanged()
                        if (messages.isNotEmpty()) {
                            messagesRecyclerView.scrollToPosition(messages.size - 1)
                        }
                    }
                }
            }
            
            override fun onFailure(call: Call<AppealDetailResponse>, t: Throwable) {
                Toast.makeText(this@AppealDetailActivity, "Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
    
    private fun sendMessage() {
        val text = messageInput.text.toString()
        if (text.isBlank()) return
        
        val request = SendMessageRequest(
            operator_id = operatorId,
            response_text = text,
            media_type = null,
            media_data = null
        )
        
        RetrofitClient.apiService.sendResponse(appealId, request).enqueue(object : Callback<ApiResponse> {
            override fun onResponse(
                call: Call<ApiResponse>,
                response: Response<ApiResponse>
            ) {
                if (response.isSuccessful) {
                    messageInput.text.clear()
                    loadAppealDetails()
                }
            }
            
            override fun onFailure(call: Call<ApiResponse>, t: Throwable) {
                Toast.makeText(this@AppealDetailActivity, "Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
    
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
