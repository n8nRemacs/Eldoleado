package com.batterycrm.app.models

data class Appeal(
    val id: Int,
    val number: String,
    val status: String,
    val channel: String,
    val client: Client?,
    val device: Device?,
    val appeal_type: String?,
    val repair_type: String?,
    val last_message: String?,
    val ai_response: String?,
    val created_at: String,
    val updated_at: String
)

data class Client(
    val id: Int? = null,
    val name: String?,
    val phone: String?
)

data class Device(
    val brand: String?,
    val model: String?
)
