package com.batterycrm.app

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.batterycrm.app.adapters.AppealsAdapter
import com.batterycrm.app.api.AppealsListResponse
import com.batterycrm.app.api.RetrofitClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    
    private lateinit var appealsRecyclerView: RecyclerView
    private lateinit var appealsAdapter: AppealsAdapter
    private val operatorId = 1 // TODO: Get from SessionManager
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        appealsRecyclerView = findViewById(R.id.appealsRecyclerView)
        
        appealsAdapter = AppealsAdapter(emptyList()) { appeal ->
            openAppealDetail(appeal.id)
        }
        
        appealsRecyclerView.layoutManager = LinearLayoutManager(this)
        appealsRecyclerView.adapter = appealsAdapter
        
        loadAppealsList()
    }
    
    private fun loadAppealsList() {
        RetrofitClient.apiService.getAppealsList(operatorId).enqueue(object : Callback<AppealsListResponse> {
            override fun onResponse(
                call: Call<AppealsListResponse>,
                response: Response<AppealsListResponse>
            ) {
                if (response.isSuccessful && response.body()?.success == true) {
                    val appeals = response.body()?.appeals ?: emptyList()
                    appealsAdapter.updateAppeals(appeals)
                } else {
                    Toast.makeText(
                        this@MainActivity,
                        "Error: ${response.code()}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            
            override fun onFailure(call: Call<AppealsListResponse>, t: Throwable) {
                Toast.makeText(
                    this@MainActivity,
                    "Network error: ${t.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }
    
    private fun openAppealDetail(appealId: Int) {
        val intent = Intent(this, AppealDetailActivity::class.java)
        intent.putExtra("appeal_id", appealId)
        startActivity(intent)
    }
    
    override fun onResume() {
        super.onResume()
        loadAppealsList()
    }
}
