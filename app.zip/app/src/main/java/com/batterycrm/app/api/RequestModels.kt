package com.batterycrm.app.api

data class SendResponseRequest(
    val operator_id: String,
    val response_text: String
)

data class SendPromoRequest(
    val operator_id: String
)

data class BasicResponse(
    val success: Boolean,
    val error: String? = null
)
