# google-services.json placeholder

- Этот файл используется только для локальной сборки.
- Перед релизом замените его реальным `google-services.json`, скачанным из Firebase Console проекта `batterycrm`.
- После замены пересоберите приложение, чтобы плагин `com.google.gms.google-services` подтянул корректные идентификаторы.




